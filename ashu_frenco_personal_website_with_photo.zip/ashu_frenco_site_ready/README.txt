ASHU FRENCO PERSONAL WEBSITE STARTER

Files:
- index.html: responsive one-page personal website with basic SEO metadata and Person structured data.
- profile-placeholder.svg: temporary graphic. Replace with your real portrait before publishing.

BEFORE PUBLISHING (IMPORTANT)
1. Open index.html in a text editor.
2. Replace every instance of https://YOUR-PUBLIC-SITE-URL.example/ with your actual published site URL.
3. Replace the LinkedIn, Instagram and YouTube sample URLs in the JSON-LD and page body with your real public profile links. Remove any platform you do not use.
4. Replace profile-placeholder.svg with your own photo named profile.jpg and update the image references in index.html to profile.jpg. Keep a professional photo you have the right to use.
5. Review all text for accuracy. Add your current job title, experience duration and projects only after verifying them. Do not add confidential employer information.
6. Preview index.html on mobile and desktop.

FREE-FIRST PUBLISHING OPTIONS
- Google Sites: https://sites.google.com/ (easy no-code option; custom HTML files cannot be uploaded as a full site there, so recreate the content in Sites).
- GitHub Pages: https://pages.github.com/ (can host these static files; requires a GitHub account and a little setup).

GOOGLE VISIBILITY CHECKLIST
- Publish a public page that loads without sign-in.
- Use your consistent name, Ashu Frenco, in the page title and main heading.
- Link to your genuine public social/professional profiles and, where appropriate, link back to the site from them.
- If using a custom domain or a host that supports it, verify the site in Google Search Console: https://search.google.com/search-console/ and request indexing.
- Recheck after some time using site:YOUR-DOMAIN and the exact name query. Indexing and display timing are not guaranteed.
- Do not buy fake press, fake followers, fake reviews, or fake knowledge-panel services. A Knowledge Panel or AI Overview is not guaranteed.


PROFILE PHOTO
- Your supplied personal photo has been added as profile.jpg.
- Before publishing, replace YOUR-PUBLIC-SITE-URL.example with your real public website URL and replace sample social profile links with your real links.
